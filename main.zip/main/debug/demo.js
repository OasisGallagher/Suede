properties {
	int x = 4;
}

shader {
	tags {
		queue = "opaque";
		queue = "geometry";
		queue = "transparent";
	}
	
	pass {
		Cull Off;
		
		@
		#include "main.inc"
		@
	}
	
	pass {
	}
	
	pass {
	}
}

shader {
	tags {
		queue = "opaque";
		queue = "geometry";
		queue = "transparent";
	}
	
	pass {
		Cull Off;
		Blend SrcAlpha OneMinusSrcAlpha;
		@
		#include "main.inc"
		@
	}
}

shader {
	pass {
	}
}
