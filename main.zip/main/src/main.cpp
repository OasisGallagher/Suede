#include "main.h"
#include "debug.h"
#include "utilities.h"
#include "language.h"
#include "syntax_tree.h"

static const char* demo = "main/debug/demo.js";
static const char* compiler = "main/config/compiler";
static const char* productions = "main/config/lr_grammar.txt";

void ReadInt(SyntaxNode* node) {
	Debug::Log(node->GetChild(0)->ToString() + " " + node->GetChild(1)->ToString());
}

void ReadFloat(SyntaxNode* node) {
	Debug::Log(node->GetChild(0)->ToString() + " " + node->GetChild(1)->ToString());
}

void ReadNumber3(SyntaxNode* node) {
	int c = 3;
	if (c > node->GetChildCount()) {
		c = node->GetChildCount();
	}
	
	for (int i = 0; i < c; ++i) {
		Debug::Log(node->GetChild(i)->ToString());
	}
}

void ReadVec3(SyntaxNode* node) {
	Debug::Log(node->GetChild(0)->ToString());
	if (node->GetChildCount() >= 2) {
		ReadNumber3(node->GetChild(1));
	}
}

void ReadTex2(SyntaxNode* node) {
	Debug::Log(node->GetChild(0)->ToString() + " " + node->GetChild(1)->ToString());
}

void ReadMat3(SyntaxNode* node) {
	Debug::Log(node->GetChild(0)->ToString());
}

void ReadMat4(SyntaxNode* node) {
	Debug::Log(node->GetChild(0)->ToString());
}

void ReadProperty(SyntaxNode* node) {
	std::string ns = node->ToString();
	if (ns == "Int") {
		ReadInt(node);
	}
	else if(ns == "Float") {
		ReadFloat(node);
	}
	else if(ns == "Vec3") {
		ReadVec3(node);
	}
	else if(ns == "Tex2") {
		ReadTex2(node);
		
	}
	else if(ns == "Mat3") {
		ReadMat3(node);
	}
	else if(ns == "Mat4") {
		ReadMat4(node);
	}
	else {
		
	}
}

void ReadProperties(SyntaxNode* node) {
	SyntaxNode* c0 = node->GetChild(0);
	if (c0->ToString() == "Properties") {
		ReadProperties(c0);
		ReadProperty(node->GetChild(1));
	}
	else {
		ReadProperty(c0);
		if (node->GetChildCount() >= 2) {
			ReadProperty(node->GetChild(1));
		}
	}
}

void ReadPropertyBlock(SyntaxNode* node) {
	SyntaxNode* c0 = node->GetChild(0);
	if (c0 == nullptr) {
		return;
	}

	if (c0->ToString() == "Properties") {
		ReadProperties(c0);
		if (node->GetChildCount() >= 2) {
			ReadProperty(node->GetChild(1));
		}
	}
	else {
		ReadProperty(c0);
	}
}

void ReadTag(SyntaxNode* node) {
	Debug::Log(node->ToString() + " " + node->GetChild(0)->ToString());
}

void ReadTags(SyntaxNode* node) {
	SyntaxNode* c0 = node->GetChild(0);
	if (c0->ToString() == "Tags") {
		ReadTags(c0);
		ReadTag(node->GetChild(1));
	}
	else {
		ReadTag(c0);
		if (node->GetChildCount() >= 2) {
			ReadTag(node->GetChild(1));
		}
	}
}

void ReadTagBlock(SyntaxNode* node) {
	if (node->GetChild(0) == nullptr) {
		return;
	}
	
	ReadTags(node->GetChild(0));
}

void ReadRenderState(SyntaxNode* node) {
	Debug::Log(node->GetChild(0)->ToString() + " " + node->GetChild(1)->ToString());
}

void ReadRenderStates(SyntaxNode* node) {
	SyntaxNode* c0 = node->GetChild(0);
	if (c0->ToString() == "RenderStates") {
		ReadRenderStates(c0);
		ReadRenderState(node->GetChild(1));
	}
	else {
		ReadRenderState(c0);
		if (node->GetChildCount() >= 2) {
			ReadRenderState(node->GetChild(1));
		}
	}
}

void ReadCode(SyntaxNode* node) {
	Debug::Log(node->ToString());
}

void ReadPass(SyntaxNode* node) {
	SyntaxNode* c0 = node->GetChild(0);
	if (c0 != nullptr) {
		if (c0->ToString() == "RenderState") {
			ReadRenderState(c0);
		}
		else {
			ReadRenderStates(c0);
		}
	}
	
	if (node->GetChild(1) != nullptr) {
		ReadCode(node->GetChild(1));
	}
}

void ReadPasses(SyntaxNode* node) {
	SyntaxNode* c0 = node->GetChild(0);
	if (c0->ToString() == "ShaderPass") {
		ReadPass(c0);
		if (node->GetChildCount() >= 2) {
			ReadPass(node->GetChild(1));
		}
	}
	else {
		ReadPasses(c0);
		ReadPass(node->GetChild(1));
	}
}

void ReadShaderBlock(SyntaxNode* node) {
	if (node->GetChild(0) != nullptr) {
		ReadTagBlock(node->GetChild(0));
	}
	
	if (node->GetChild(1)->ToString() == "ShaderPass") {
		ReadPass(node->GetChild(1));
	}
	else {
		ReadPasses(node->GetChild(1));
	}
}

void ReadShaderBlocks(SyntaxNode* node) {
	SyntaxNode* c0 = node->GetChild(0);
	if (c0->ToString() == "ShaderBlocks") {
		ReadShaderBlocks(c0);
		ReadShaderBlock(node->GetChild(1));
	}
	else {
		ReadShaderBlock(c0);
		if (node->GetChildCount() >= 2) {
			ReadShaderBlock(node->GetChild(1));
		}
	}
}

void Read(SyntaxNode* node) {
	ReadPropertyBlock(node->GetChild(0));
	SyntaxNode* c1 = node->GetChild(1);
	if (c1->ToString() == "ShaderBlock") {
		ReadShaderBlock(c1);
	}
	else {
		ReadShaderBlocks(c1);
	}
}

void Translate(SyntaxTree& tree) {
	Read(tree.GetRoot());
	//tree.PreorderTreeWalk(TreeWalkEnter, TreeWalkExit);
}

int main(int argc, char** argv) {
	Debug::EnableMemoryLeakCheck();

	Language* lang = new Language;
	lang->Setup(productions, compiler);

	//Debug::Log(lang->ToString());

	SyntaxTree tree;

	if (lang->Parse(&tree, demo)) {
		Debug::Log("\n" + Utility::Heading(" SyntaxTree "));
		Debug::Log(tree.ToString());
	}

	Translate(tree);

 	delete lang;

	return 0;
}
